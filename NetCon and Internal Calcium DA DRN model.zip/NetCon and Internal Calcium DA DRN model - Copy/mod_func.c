#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _A_reg();
extern void _AMPANetCon_reg();
extern void _CaW_reg();
extern void _GABANetCon_reg();
extern void _Gfluc_reg();
extern void _H_reg();
extern void _HHH_reg();
extern void _M_reg();
extern void _NMDANetCon_reg();
extern void _NaP_reg();
extern void _cabalanmod_reg();
extern void _capumpmod_reg();
extern void _kca_reg();
extern void _netstims_reg();
extern void _netstimss_reg();
extern void _netstimsss_reg();

void modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," A.mod");
fprintf(stderr," AMPANetCon.mod");
fprintf(stderr," CaW.mod");
fprintf(stderr," GABANetCon.mod");
fprintf(stderr," Gfluc.mod");
fprintf(stderr," H.mod");
fprintf(stderr," HHH.mod");
fprintf(stderr," M.mod");
fprintf(stderr," NMDANetCon.mod");
fprintf(stderr," NaP.mod");
fprintf(stderr," cabalanmod.mod");
fprintf(stderr," capumpmod.mod");
fprintf(stderr," kca.mod");
fprintf(stderr," netstims.mod");
fprintf(stderr," netstimss.mod");
fprintf(stderr," netstimsss.mod");
fprintf(stderr, "\n");
    }
_A_reg();
_AMPANetCon_reg();
_CaW_reg();
_GABANetCon_reg();
_Gfluc_reg();
_H_reg();
_HHH_reg();
_M_reg();
_NMDANetCon_reg();
_NaP_reg();
_cabalanmod_reg();
_capumpmod_reg();
_kca_reg();
_netstims_reg();
_netstimss_reg();
_netstimsss_reg();
}
